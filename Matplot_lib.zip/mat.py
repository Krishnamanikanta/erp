import pandas as pd
import matplotlib.pyplot as plt

file_path = "sales_realtime_data.xlsx"
df = pd.read_excel(r"C:\Users\user\Downloads\sales_realtime_data.xlsx")

df['Date'] = pd.to_datetime(df['Date'])

# 1. Line Plot - Sales trend over time
plt.figure(figsize=(10,6))
df.groupby("Date")["TotalSales"].sum().plot(kind="line", marker="o")
plt.title("Total Sales Trend Over Time")
plt.xlabel("Date")
plt.ylabel("Total Sales")
plt.grid(True)
plt.show()

# 2. Bar Chart - Sales by Region
plt.figure(figsize=(8,5))
df.groupby("Region")["TotalSales"].sum().plot(kind="bar", color="skyblue")
plt.title("Total Sales by Region")
plt.ylabel("Total Sales")
plt.show()

# 3. Stacked Bar Chart - Sales by Region & SalesPerson
plt.figure(figsize=(10,6))
df.groupby(["Region","SalesPerson"])["TotalSales"].sum().unstack().plot(kind="bar", stacked=True)
plt.title("Stacked Sales by Region and SalesPerson")
plt.ylabel("Total Sales")
plt.show()

# 4. Scatter Plot - Units vs Total Sales
plt.figure(figsize=(8,5))
plt.scatter(df["Units"], df["TotalSales"], alpha=0.6, c=df["UnitPrice"], cmap="viridis")
plt.colorbar(label="Unit Price")
plt.title("Scatter: Units vs Total Sales")
plt.xlabel("Units")
plt.ylabel("Total Sales")
plt.show()

# 5. Histogram - Distribution of Total Sales
plt.figure(figsize=(8,5))
plt.hist(df["TotalSales"], bins=15, color="orange", edgecolor="black")
plt.title("Histogram of Total Sales")
plt.xlabel("Total Sales")
plt.ylabel("Frequency")
plt.show()

# 6. Pie Chart - Sales share by Region
plt.figure(figsize=(6,6))
df.groupby("Region")["TotalSales"].sum().plot(kind="pie", autopct="%1.1f%%")
plt.title("Sales Share by Region")
plt.ylabel("")
plt.show()

# 7. Boxplot - Distribution of Sales by Region
plt.figure(figsize=(8,5))
df.boxplot(column="TotalSales", by="Region")
plt.title("Boxplot of Total Sales by Region")
plt.suptitle("")
plt.xlabel("Region")
plt.ylabel("Total Sales")
plt.show()

# 8. Area Plot - Cumulative Sales over time
plt.figure(figsize=(10,6))
df.groupby("Date")["TotalSales"].sum().cumsum().plot(kind="area", alpha=0.5, color="green")
plt.title("Cumulative Sales Over Time (Area Plot)")
plt.xlabel("Date")
plt.ylabel("Cumulative Sales")
plt.show()
